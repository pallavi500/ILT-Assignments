package com.Junit;

import java.util.List;

public interface EmployeeDao {

	public Employee getByEmployeeId(int id);
	public Employee createEmployee();
	public Employee deleteEmployee(int id);
	public List<Employee> listEmployee();
	public Employee searchEmployeeByName(String name);
}
