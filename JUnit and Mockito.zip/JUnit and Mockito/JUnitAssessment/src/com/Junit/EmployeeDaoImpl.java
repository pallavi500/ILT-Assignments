package com.Junit;

import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public Employee getByEmployeeId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee createEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}
    @Override
	public  List<Employee> listEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee searchEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
