package com.Test;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.Junit.Employee;
import com.Junit.EmployeeDaoImpl;

public class EmployeeJunitTest {
@Mock
EmployeeDaoImpl employeeDao=Mockito.mock(EmployeeDaoImpl.class);


	@Test
	public void testListEmployee() {
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(101, "Mahie", 20000));
		list.add(new Employee(102, "Kavya", 50000));
		list.add(new Employee(103, "Shiva", 40000));
		list.add(new Employee(104, "Rupa", 60000));
		list.add(new Employee(105, "Sindhu", 50000));
		
		Mockito.when(employeeDao.listEmployee()).thenReturn(list);
		}
	
	@Test
	public void testGetEmployeeById(int id) {
		Employee e=new Employee(101, "Madhu", 50000);
		id=e.getEmpId();
    	Mockito.when(employeeDao.getByEmployeeId(id)).thenReturn(e);
	}
	
	@Test
	public void testCreateEmployee() {
		Employee e=new Employee(101, "Madhu", 50000);
		Mockito.when(employeeDao.createEmployee()).thenReturn(e);
	}
	
	@Test
	public void testDeleteEmployee() {
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(101, "Mahie", 20000));
		Employee e=list.remove(0);
		int id=e.getEmpId();
		Mockito.when(employeeDao.deleteEmployee(id)).thenReturn(e);
	}
	
	@Test
	public void testSearchEmployeeByName() {
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(101, "Mahie", 20000));
		Employee e=list.get(0);
		String name=e.getEmpName();
		Mockito.when(employeeDao.searchEmployeeByName(name)).thenReturn(e);
	}

}