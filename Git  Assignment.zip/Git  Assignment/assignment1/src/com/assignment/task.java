package com.assignment;

import java.util.Scanner;

public class task {
	public static void main(String[] args)
	{
		System.out.println("welcome pallavi");
		Scanner sc=new Scanner(System.in);
		System.out.println("Write something");
		String p=sc.nextLine();
		System.out.println("hiii");
	}

}
