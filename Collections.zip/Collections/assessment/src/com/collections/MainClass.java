package com.collections;

import java.util.HashSet;
import java.util.Set;

public class MainClass {
public static void main(String[] args) {
	
	Set<Employee> set=new HashSet<Employee>();
    set.add(new Employee(101, "Madhupriya","Bangalore", 350000, '5', 456-456, "madhupriya@gmail.com"));
    set.add(new Employee(102, "Tara","Chennai", 350000, '5', 356-459, "taratara@gmail.com"));
    set.add(new Employee(103, "vaishnavi","Hyderabad", 350000, '5', 556-456, "vaishnavi@gmail.com"));
    set.add(new Employee(104, "Priyanka","Kochi", 350000, '5', 56-456, "priyankapri@gmail.com"));
    
    set.add(new Employee(101, "Madhupriya","Bangalore", 350000, '5', 456-456, "madhupriya@gmail.com"));
	
	System.out.println(set);
}
}
