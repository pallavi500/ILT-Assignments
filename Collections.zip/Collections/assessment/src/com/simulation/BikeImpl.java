package com.simulation;

public class BikeImpl implements Design{
	 
	
	private int bikeNum;
	private String bikeMode;
	private	double bikePrice;
	public int getBikeNum() {
		return bikeNum;
	}

	public void setBikeNum(int bikeNum) {
		this.bikeNum = bikeNum;
	}

	public String getBikeMode() {
		return bikeMode;
	}

	public void setBikeMode(String bikeMode) {
		this.bikeMode = bikeMode;
	}

	public double getBikePrice() {
		return bikePrice;
	}

	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}

	@Override
	public void start() {
		System.out.println("Bike started...!");
		
	}

	@Override
	public void stop() {
		System.out.println("Bike Stopped...!");
		
	}

}
