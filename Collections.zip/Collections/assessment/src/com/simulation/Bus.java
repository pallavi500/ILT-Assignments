package com.simulation;

import java.util.Scanner;

public class Bus{

	void Details() {
		
		BusImpl bus=new BusImpl();
		Scanner sc=new Scanner(System.in);
		String choice;
		System.out.println("Welcome to Bus");
		System.out.println("Enetr your bus number:");
		int busNum=sc.nextInt();
		bus.setBusNum(busNum);
		System.out.println("Enter your bus Model:");
		String busModel=sc.next();
		bus.setBusModel(busModel);
		System.out.println("Enter the price of your bus:");
		double busPrice=sc.nextDouble();
		bus.setBusPrice(busPrice);
		
		System.out.println("The details of the bus are:");
		
		System.out.println("Bus Number: "+busNum);
		System.out.println("Bus Model: "+busModel);
		System.out.println("Bus Number: "+busPrice);
		
		System.out.println("If you want to start or stop the bus....");
		System.out.println("Press 1 to start\n Press 2 to stop\n Press q. to exit");
		choice=sc.next();
		
		switch(choice) {
		
		case "1": bus.start();
		          break;
		
		case "2": bus.stop();
		          break;
		          
		case "q": System.out.println("Thank you for visiting");
		          break;
		
		default: System.out.println("Please enter a valid choice");
		}
		sc.close();
	}
}


