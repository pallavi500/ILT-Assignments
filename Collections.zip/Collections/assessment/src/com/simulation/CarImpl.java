package com.simulation;

public class CarImpl implements Design {
   private int carNum;
	private String carModel;
	private double carPrice;
	public int getCarNum() {
		return carNum;
	}

	public void setCarNum(int carNum) {
		this.carNum = carNum;
	}

	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public double getCarPrice() {
		return carPrice;
	}

	public void setCarPrice(double carPrice) {
		this.carPrice = carPrice;
	}

	

	@Override
	public void start() {
		System.out.println("Car started...!");
		
	}

	@Override
	public void stop() {
		System.out.println("Car stopped...!");
		
	}

}
