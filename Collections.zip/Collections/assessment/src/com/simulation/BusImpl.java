package com.simulation;

public class BusImpl implements Design {

	 private int busNum;
	 public int getBusNum() {
		return busNum;
	}
	public void setBusNum(int busNum) {
		this.busNum = busNum;
	}
	public String getBusModel() {
		return busModel;
	}
	public void setBusModel(String busModel) {
		this.busModel = busModel;
	}
	public double getBusPrice() {
		return busPrice;
	}
	public void setBusPrice(double busPrice) {
		this.busPrice = busPrice;
	}
	private String busModel;
	 private double busPrice;
		@Override
		public void start() {
            System.out.println("Bus Started...!");			
		}
		@Override
		public void stop() {
			System.out.println("Bike Stopped...!");
			
		}
		
		
}
