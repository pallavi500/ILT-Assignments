package com.simulation;

import java.util.Scanner;

public class Bike{

	void Details() {
		
		BikeImpl bike=new BikeImpl();
		Scanner sc=new Scanner(System.in);
		String choice;
		System.out.println("Welcome to bike");
		
		System.out.println("Enetr your bike number:");
		int bikeNum=sc.nextInt();
		bike.setBikeNum(bikeNum);
		System.out.println("Enter your bike Model:");
		String bikeModel=sc.next();
		bike.setBikeMode(bikeModel);
		System.out.println("Enter the price of your bike:");
		double bikePrice=sc.nextDouble();
		bike.setBikePrice(bikePrice);
		
		System.out.println("The details of the bike are:");
		
		System.out.println("Bike Number: "+bikeNum);
		System.out.println("Bike Model: "+bikeModel);
		System.out.println("Bike Number: "+bikePrice);
		
		System.out.println("If you want to start or stop the bike....");
		System.out.println("Press 1 to start\n Press 2 to stop\n Press q to exit");
		choice=sc.next();
		
		switch(choice) {
		
		case "1": bike.start();
		          break;
		
		case "2": bike.stop();
		          break;
		          
		case "q": System.out.println("Thank you for visiting");
		          break;
		
		default: System.out.println("Please enter a valid choice");
		}
		sc.close();
	}
}


