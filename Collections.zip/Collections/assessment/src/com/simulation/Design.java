package com.simulation;

public interface Design{

	void start();
	void stop();
	
	
}
