package com.simulation;

import java.util.Scanner;

public class Car {
void Details() {
	CarImpl car=new CarImpl();
	
	Scanner sc=new Scanner(System.in);
	String choice;
	System.out.println("Welcome to car");
	
	System.out.println("Enetr your car number:");
	int carNum=sc.nextInt();
	car.setCarNum(carNum);
	System.out.println("Enter the car Model:");
	String carModel=sc.next();
	car.setCarModel(carModel);
	System.out.println("Enter the price of your car:");
	double carPrice=sc.nextDouble();
	car.setCarPrice(carPrice);
	
	System.out.println("The details of the car are:");
	
	System.out.println("Car Number: "+carNum);
	System.out.println("Car Model: "+carModel);
	System.out.println("Car Number: "+carPrice);
	
	System.out.println("If you want to start or stop the car....");
	System.out.println("Press 1.to start\tPress 2.to stop\tPress q.to exit");
	choice=sc.next();
	
	switch(choice) {
	
	case "1": car.start();
	          break;
	
	case "2": car.stop();
	          break;
	          
	case "q": System.out.println("Thank you for visiting");
	          break;
	
	default: System.out.println("Please enter a valid choice");
	}
	sc.close();
}
}
