package com.simulation;

import java.util.Scanner;

public class MainClass {
public static void main(String[] args) {
	String choice;
    Scanner sc=new Scanner(System.in);
	System.out.println("Welcome to Vechicle simulation...!");
	System.out.println("Plase enter your choice of vechicle:");
	System.out.println("1.Car\t2.Bike\t3.Bus\tand q to quit");
	choice=sc.next();
	switch(choice) {
	
	case "1": Car car= new Car();
	          car.Details();
	          break;
	          
	case "2": Bike bike=new Bike();
	          bike.Details();
	          break;
	case "3": Bus bus=new Bus();
	          bus.Details();
	          break;
	case "q": System.out.println("Thank you for Visiting...!");
	          break;
	default: System.out.println("Please enter a vails choice....");
	         break;
	}
	sc.close();
	
}
}
	


