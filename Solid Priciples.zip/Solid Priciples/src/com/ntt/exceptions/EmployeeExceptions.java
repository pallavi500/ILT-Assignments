package com.ntt.exceptions;

public class EmployeeExceptions extends Exception {
	
	
	public EmployeeExceptions(String message){
		super(message);
	
	}

}
