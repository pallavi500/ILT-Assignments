package com.ntt;

public class User {
	private String username;
	private String address;
	private long phone_no;
	public long getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	private Account acc;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account getAcc() {
		return acc;
	}
	public void setAcc(Account acc) {
		this.acc = acc;
	}
	public User() {
		super();
	}
	public User(String username, String address, long phone_no, Account acc) {
		super();
		this.username = username;
		this.address = address;
		this.phone_no = phone_no;
		this.acc = acc;
	}
}
