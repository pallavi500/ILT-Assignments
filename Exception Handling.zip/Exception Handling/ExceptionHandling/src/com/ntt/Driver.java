package com.ntt;

import java.util.Scanner;

public class Driver {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Account acc1=null;
		User user1=null;
		Account acc2=null;
		User user2=null;
		
		int ch;
		do
		{
			System.out.println("Welcome to Bank Application");
			System.out.println("1.Create Account\n 2.Transfer Funds \n 3.Exit");
			System.out.println("Select any one of the above options");
			ch=s.nextInt();
			switch(ch)
			{
			case 1:	int ch1;
					do
					{
						System.out.println("1.Create account\n 2. Recreate account\n 3.Quit");
						System.out.println("Enter your choice");
						ch1=s.nextInt();
						switch(ch1)
						{
						case 1:
							
							System.out.println("Enter the Account Id");
							int accid=s.nextInt();
							System.out.println("Enter the Amount");
							double amt=s.nextDouble();
							
							System.out.println("Enter the user name");
							String name=s.next();
							System.out.println("Enter the Address");
							String adress=s.next();
							System.out.println("Enter the phonenumber");
							Long phno=s.nextLong();
							 acc1=new Account(accid,amt);
							 user1=new User(name,adress,phno,acc1);
							 
							
						        System.out.println("Account created succesfully!..");
						        break;
						case 2:
							Account a1=new Account();
							System.out.println("Enter the Account Id");
							int accid1=s.nextInt();
							System.out.println("Enter the Amount");
							double amt1=s.nextDouble();
							
							System.out.println("Enter the user name");
							String name1=s.next();
							System.out.println("Enter the Address");
							String adress1=s.next();
							System.out.println("Enter the phonenumber");
							Long phno1=s.nextLong();
							acc2=new Account(accid1,amt1);
							 user2=new User(name1,adress1,phno1,acc2);
							
								System.out.println("Account created succesfully!..");
							
							
								break;
						
						}
						
							
					}while(ch1!=2);
					break;
			case 2: 
				int ch2;
					do
					{
						System.out.println("1. Transfer Funds from user1 to user2");
						System.out.println("2.Transfer Funds from user2 to user1");
						System.out.println("3. Quit");
						System.out.println("Enter the choice");
						ch2=s.nextInt();
						switch(ch2)
						{
						case 1: Bank bank=new Bank();
						          System.out.println("user1 Account Details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
						          System.out.println("user2 Account Details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount"+user2.getAcc().getAmount());
								
								System.out.println("Enter the amount to be tranfered");
								double amount=s.nextDouble();
							try {
								bank.TransferFund(user1,user2,amount);
							} catch (InsuficientamtException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
								System.out.println("Trasfered amount from user 1 to user 2 successfully!!");
								System.out.println("user1 Account Details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
								System.out.println("user2 Account Details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount\t"+user2.getAcc().getAmount());
								break;
						case 2: Bank bank1=new Bank();
						        System.out.println("user1 Account Details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
					      	    System.out.println("user2 Account Details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount\t\t"+user2.getAcc().getAmount());
						
								System.out.println("Enter the amount to be tranfered");
								double amount1=s.nextDouble();
							try {
								bank1.TransferFund(user2,user1,amount1);
							} catch (InsuficientamtException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
								System.out.println("Trasfered amount from user 2 to user 1 successfully!!");
								System.out.println("user1 Account Details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
								System.out.println("user2 Account Details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount\t"+user2.getAcc().getAmount());
								break;
						}
						
					}while(ch2!=3);
				
			}
					
			
		}while(ch!=3);

	}

}
