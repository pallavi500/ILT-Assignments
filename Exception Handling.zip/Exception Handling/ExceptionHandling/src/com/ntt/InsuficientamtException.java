package com.ntt;

public class InsuficientamtException extends Exception {
	InsuficientamtException(String s){
		super(s);
	}
}
