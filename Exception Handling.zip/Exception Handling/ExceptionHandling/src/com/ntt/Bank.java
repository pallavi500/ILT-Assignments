package com.ntt;

import java.util.Scanner;

public class Bank {

	void TransferFund(	User u1,User u2,double amount) throws InsuficientamtException
	{
		if(u1.getAcc().getAmount()<amount)
		{
			throw new InsuficientamtException("Insuffiecient balance");
		}
		else
		{
		double amtu1=	u1.getAcc().getAmount();
	double	amt1=amtu1-amount;
	u1.getAcc().setAmount(amt1);
	double amtu2=	u2.getAcc().getAmount();
	double	amt2=amtu2+amount;
	u2.getAcc().setAmount(amt2);
		}
	}
	
	
}
